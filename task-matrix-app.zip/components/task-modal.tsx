"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import type { Task } from "@/lib/types"

interface TaskModalProps {
  task: Task | null
  onSave: (task: Partial<Task>) => void
  onClose: () => void
}

const urgencyLabels = [
  "1年",
  "半年",
  "3个月",
  "1个月",
  "1周",
  "3天",
  "1天",
  "10小时",
  "4小时",
  "2小时",
  "1小时",
  "30分钟",
  "15分钟",
]
const priorityColors = ["#4444ff", "#0088cc", "#00cc88", "#88cc00", "#ffcc00", "#ff8800", "#ff4444"]

export function TaskModal({ task, onSave, onClose }: TaskModalProps) {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [category, setCategory] = useState("work")
  const [importance, setImportance] = useState(4)
  const [urgency, setUrgency] = useState(5)

  useEffect(() => {
    if (task) {
      setTitle(task.title)
      setDescription(task.description || "")
      setCategory(task.category)
      setImportance(task.importance)
      setUrgency(task.urgency)
    } else {
      setTitle("")
      setDescription("")
      setCategory("work")
      setImportance(4)
      setUrgency(5)
    }
  }, [task])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!title.trim()) {
      alert("请输入任务标题")
      return
    }

    onSave({
      title: title.trim(),
      description: description.trim(),
      category,
      importance,
      urgency,
    })
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl p-8 w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl">
        <h2 className="text-2xl font-bold mb-6 text-gray-800">{task ? "编辑任务" : "添加新任务"}</h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="title">任务标题 *</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="输入任务标题"
              required
            />
          </div>

          <div>
            <Label htmlFor="description">任务描述</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="详细描述您的任务..."
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="category">任务分类</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="work">工作</SelectItem>
                <SelectItem value="personal">个人</SelectItem>
                <SelectItem value="study">学习</SelectItem>
                <SelectItem value="health">健康</SelectItem>
                <SelectItem value="family">家庭</SelectItem>
                <SelectItem value="other">其他</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>
              重要程度（当前：
              <span style={{ color: priorityColors[importance - 1], fontWeight: "bold" }}>{importance}星</span>）
            </Label>
            <Slider
              value={[importance]}
              onValueChange={(value) => setImportance(value[0])}
              min={1}
              max={7}
              step={1}
              className="mt-2"
            />
          </div>

          <div>
            <Label htmlFor="urgency">紧急程度（当前：{urgencyLabels[urgency]}）</Label>
            <Select value={urgency.toString()} onValueChange={(value) => setUrgency(Number.parseInt(value))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {urgencyLabels.map((label, index) => (
                  <SelectItem key={index} value={index.toString()}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              取消
            </Button>
            <Button type="submit" className="flex-1">
              保存
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
