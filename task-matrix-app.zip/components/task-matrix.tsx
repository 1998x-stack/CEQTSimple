"use client"

import type React from "react"

import { useState, useRef } from "react"
import type { Task } from "@/lib/types"
import { TaskItem } from "./task-item"
import { AddButton } from "./add-button"

interface TaskMatrixProps {
  tasks: Task[]
  onAddTask: (x: number, y: number) => void
  onEditTask: (task: Task) => void
  onContextMenu: (e: React.MouseEvent, taskId: string) => void
  onTaskMove: (taskId: string, urgency: number, importance: number) => void
}

const urgencyLabels = [
  "1年",
  "半年",
  "3个月",
  "1个月",
  "1周",
  "3天",
  "1天",
  "10小时",
  "4小时",
  "2小时",
  "1小时",
  "30分钟",
  "15分钟",
]
const importanceLabels = ["1星", "2星", "3星", "4星", "5星", "6星", "7星"]
const priorityColors = ["#4444ff", "#0088cc", "#00cc88", "#88cc00", "#ffcc00", "#ff8800", "#ff4444"]

export function TaskMatrix({ tasks, onAddTask, onEditTask, onContextMenu, onTaskMove }: TaskMatrixProps) {
  const [showAddButton, setShowAddButton] = useState(false)
  const [addButtonPos, setAddButtonPos] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const matrixRef = useRef<HTMLDivElement>(null)

  const coordinateToPosition = (urgency: number, importance: number) => {
    if (!matrixRef.current) return { x: 0, y: 0 }

    const { offsetWidth: width, offsetHeight: height } = matrixRef.current
    const cellWidth = width / 12
    const cellHeight = height / 6

    const x = cellWidth / 2 + urgency * cellWidth
    const y = cellHeight / 2 + (7 - importance) * cellHeight

    return { x, y }
  }

  const positionToCoordinate = (x: number, y: number) => {
    if (!matrixRef.current) return { urgency: 6, importance: 4 }

    const { offsetWidth: width, offsetHeight: height } = matrixRef.current
    const cellWidth = width / 12
    const cellHeight = height / 6

    let urgency = Math.round((x - cellWidth / 2) / cellWidth)
    let importance = 7 - Math.round((y - cellHeight / 2) / cellHeight)

    urgency = Math.max(0, Math.min(12, urgency))
    importance = Math.max(1, Math.min(7, importance))

    return { urgency, importance }
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) return

    const rect = matrixRef.current?.getBoundingClientRect()
    if (!rect) return

    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    setAddButtonPos({ x, y })
    setShowAddButton(true)
  }

  const handleMouseLeave = () => {
    if (!isDragging) {
      setShowAddButton(false)
    }
  }

  const handleAddButtonClick = () => {
    onAddTask(addButtonPos.x, addButtonPos.y)
  }

  return (
    <div className="flex items-center justify-center min-h-screen p-5 pt-20">
      <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-10 shadow-2xl w-full max-w-5xl">
        <div
          ref={matrixRef}
          className="relative w-full h-[600px] border-2 border-gray-300 bg-gray-50 rounded-xl overflow-visible"
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
        >
          {/* Quadrant Labels */}
          <div className="absolute top-5 left-5 text-lg font-bold text-black/20 pointer-events-none">重要不紧急</div>
          <div className="absolute top-5 right-5 text-lg font-bold text-black/20 pointer-events-none">重要紧急</div>
          <div className="absolute bottom-5 left-5 text-lg font-bold text-black/20 pointer-events-none">
            不重要不紧急
          </div>
          <div className="absolute bottom-5 right-5 text-lg font-bold text-black/20 pointer-events-none">
            不重要紧急
          </div>

          {/* Axes */}
          <div className="absolute top-1/2 left-0 w-full h-1 bg-gradient-to-r from-green-500 to-blue-500 z-10">
            <div className="absolute -top-2 right-0 w-0 h-0 border-l-3 border-l-blue-500 border-t-2 border-t-transparent border-b-2 border-b-transparent"></div>
          </div>
          <div className="absolute left-1/2 top-0 w-1 h-full bg-gradient-to-t from-orange-500 to-red-500 z-10">
            <div className="absolute -left-2 top-0 w-0 h-0 border-b-3 border-b-red-500 border-l-2 border-l-transparent border-r-2 border-r-transparent"></div>
          </div>

          {/* Grid Lines */}
          {Array.from({ length: 13 }, (_, i) => (
            <div
              key={`v-${i}`}
              className="absolute w-px h-full bg-black/5"
              style={{ left: `calc(50% + ${(i - 6) * (100 / 12)}%)` }}
            />
          ))}
          {Array.from({ length: 7 }, (_, i) => (
            <div
              key={`h-${i}`}
              className="absolute w-full h-px bg-black/5"
              style={{ top: `calc(50% + ${(3 - i) * (100 / 6)}%)` }}
            />
          ))}

          {/* Urgency Labels */}
          {urgencyLabels.map((label, i) => (
            <div
              key={`urgency-${i}`}
              className="absolute text-xs text-gray-600 font-bold bg-white/70 px-2 py-1 rounded-lg z-20"
              style={{
                left: `calc(50% + ${((i - 6) * (100 / 12) * 7) / 8}% - 20px)`,
                bottom: "5px",
                opacity: 0.3 + (i / 12) * 0.7,
              }}
            >
              {label}
            </div>
          ))}

          {/* Importance Labels */}
          {importanceLabels.map((label, i) => (
            <div
              key={`importance-${i}`}
              className="absolute text-xs font-bold bg-white/70 px-2 py-1 rounded-lg z-20"
              style={{
                left: "5px",
                top: `calc(50% + ${((3 - i) * (100 / 6) * 5) / 6}% - 8px)`,
                color: priorityColors[i],
              }}
            >
              {label}
            </div>
          ))}

          {/* Tasks */}
          {tasks.map((task) => {
            const position = coordinateToPosition(task.urgency, task.importance)
            return (
              <TaskItem
                key={task.id}
                task={task}
                position={position}
                onEdit={onEditTask}
                onContextMenu={onContextMenu}
                onMove={(newUrgency, newImportance) => onTaskMove(task.id, newUrgency, newImportance)}
                positionToCoordinate={positionToCoordinate}
                matrixRef={matrixRef}
                setIsDragging={setIsDragging}
              />
            )
          })}

          {/* Add Button */}
          {showAddButton && <AddButton position={addButtonPos} onClick={handleAddButtonClick} />}
        </div>
      </div>
    </div>
  )
}
