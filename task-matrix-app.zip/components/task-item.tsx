"use client"

import type React from "react"

import { useState, useRef } from "react"
import type { Task } from "@/lib/types"

interface TaskItemProps {
  task: Task
  position: { x: number; y: number }
  onEdit: (task: Task) => void
  onContextMenu: (e: React.MouseEvent, taskId: string) => void
  onMove: (urgency: number, importance: number) => void
  positionToCoordinate: (x: number, y: number) => { urgency: number; importance: number }
  matrixRef: React.RefObject<HTMLDivElement>
  setIsDragging: (dragging: boolean) => void
}

const priorityColors = ["#4444ff", "#0088cc", "#00cc88", "#88cc00", "#ffcc00", "#ff8800", "#ff4444"]
const urgencyLabels = [
  "1年",
  "半年",
  "3个月",
  "1个月",
  "1周",
  "3天",
  "1天",
  "10小时",
  "4小时",
  "2小时",
  "1小时",
  "30分钟",
  "15分钟",
]

const getCategoryName = (category: string) => {
  const categoryMap: Record<string, string> = {
    work: "工作",
    personal: "个人",
    study: "学习",
    health: "健康",
    family: "家庭",
    other: "其他",
  }
  return categoryMap[category] || "其他"
}

export function TaskItem({
  task,
  position,
  onEdit,
  onContextMenu,
  onMove,
  positionToCoordinate,
  matrixRef,
  setIsDragging,
}: TaskItemProps) {
  const [showTooltip, setShowTooltip] = useState(false)
  const [isDragging, setLocalDragging] = useState(false)
  const [dragPosition, setDragPosition] = useState(position)
  const taskRef = useRef<HTMLDivElement>(null)

  const getTaskColor = (importance: number, urgency: number) => {
    const baseColor = priorityColors[importance - 1]
    const opacity = 0.4 + (urgency / 12) * 0.6
    return (
      baseColor +
      Math.floor(opacity * 255)
        .toString(16)
        .padStart(2, "0")
    )
  }

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return // Only left click

    setLocalDragging(true)
    setIsDragging(true)

    const handleMouseMove = (e: MouseEvent) => {
      if (!matrixRef.current) return

      const rect = matrixRef.current.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top

      setDragPosition({ x, y })
    }

    const handleMouseUp = (e: MouseEvent) => {
      if (!matrixRef.current) return

      const rect = matrixRef.current.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top
      const coords = positionToCoordinate(x, y)

      onMove(coords.urgency, coords.importance)

      setLocalDragging(false)
      setIsDragging(false)
      setDragPosition(position)

      document.removeEventListener("mousemove", handleMouseMove)
      document.removeEventListener("mouseup", handleMouseUp)
    }

    document.addEventListener("mousemove", handleMouseMove)
    document.addEventListener("mouseup", handleMouseUp)
  }

  const currentPosition = isDragging ? dragPosition : position

  return (
    <>
      <div
        ref={taskRef}
        className={`absolute w-8 h-8 rounded-full cursor-pointer border-2 border-white/80 shadow-lg transition-all duration-300 flex items-center justify-center text-white font-bold text-xs z-20 hover:scale-150 hover:shadow-xl ${isDragging ? "z-50" : ""}`}
        style={{
          left: currentPosition.x - 16,
          top: currentPosition.y - 16,
          backgroundColor: getTaskColor(task.importance, task.urgency),
        }}
        onMouseDown={handleMouseDown}
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
        onContextMenu={(e) => onContextMenu(e, task.id)}
        onDoubleClick={() => onEdit(task)}
      >
        {task.title.charAt(0).toUpperCase()}
      </div>

      {/* Tooltip */}
      {showTooltip && !isDragging && (
        <div
          className="absolute bg-black/85 text-white p-3 rounded-lg text-sm max-w-70 pointer-events-none z-50 shadow-lg"
          style={{
            left: currentPosition.x,
            top: currentPosition.y - 60,
            transform: "translateX(-50%)",
          }}
        >
          <div className="font-bold mb-1">{task.title}</div>
          <div className="text-xs space-y-1">
            <div>重要程度: {task.importance}星</div>
            <div>紧急程度: {urgencyLabels[task.urgency]}</div>
            <div>分类: {getCategoryName(task.category)}</div>
          </div>
          <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-2 border-r-2 border-t-2 border-l-transparent border-r-transparent border-t-black/85"></div>
        </div>
      )}
    </>
  )
}
