"use client"

import { useMemo } from "react"
import type { Task } from "@/lib/types"
import { getCategoryName } from "@/lib/utils"

interface CategoryChartProps {
  tasks: Task[]
}

const categoryColors = ["#FF6B6B", "#4ECDC4", "#FFD166", "#6A0572", "#1A936F", "#114B5F"]

export function CategoryChart({ tasks }: CategoryChartProps) {
  const categoryData = useMemo(() => {
    const categories = ["work", "personal", "study", "health", "family", "other"]
    const data = categories
      .map((cat, index) => ({
        name: getCategoryName(cat),
        count: tasks.filter((t) => t.category === cat).length,
        color: categoryColors[index],
      }))
      .filter((item) => item.count > 0)

    const total = data.reduce((sum, item) => sum + item.count, 0)

    return data.map((item) => ({
      ...item,
      percentage: total > 0 ? Math.round((item.count / total) * 100) : 0,
    }))
  }, [tasks])

  if (categoryData.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">暂无任务数据</p>
      </div>
    )
  }

  return (
    <div>
      <h3 className="text-lg font-bold mb-4">任务分类分布</h3>
      <div className="space-y-3">
        {categoryData.map((item, index) => (
          <div key={index} className="flex items-center gap-4">
            <div className="w-4 h-4 rounded-full flex-shrink-0" style={{ backgroundColor: item.color }} />
            <div className="flex-1">
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm font-medium">{item.name}</span>
                <span className="text-sm text-gray-600">
                  {item.count} ({item.percentage}%)
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="h-2 rounded-full transition-all duration-500"
                  style={{
                    backgroundColor: item.color,
                    width: `${item.percentage}%`,
                  }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
