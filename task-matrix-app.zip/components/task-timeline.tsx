import type { Task } from "@/lib/types"
import { formatDate, getCategoryName, getTaskColor } from "@/lib/utils"

interface TaskTimelineProps {
  tasks: Task[]
  type: "created" | "completed"
}

export function TaskTimeline({ tasks, type }: TaskTimelineProps) {
  if (tasks.length === 0) {
    return <p className="text-gray-500 text-center py-8">{type === "created" ? "暂无创建的任务" : "暂无完成的任务"}</p>
  }

  return (
    <div className="space-y-4 max-h-96 overflow-y-auto">
      {tasks.map((task) => {
        const dateToShow = type === "created" ? task.createdAt : task.completedAt
        if (!dateToShow) return null

        return (
          <div key={task.id} className="flex items-center gap-4 p-3 border-b border-gray-100 last:border-b-0">
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xs flex-shrink-0"
              style={{ backgroundColor: getTaskColor(task.importance, task.urgency) }}
            >
              {task.title.charAt(0).toUpperCase()}
            </div>

            <div className="flex-shrink-0 text-xs text-gray-500 w-24">{formatDate(dateToShow)}</div>

            <div className="flex-1 min-w-0">
              <div className="font-medium text-sm truncate">
                {type === "completed" && "✅ "}
                {task.title}
              </div>
              <div className="flex flex-wrap gap-2 mt-1">
                <span className="bg-gray-100 text-xs px-2 py-1 rounded-full">{getCategoryName(task.category)}</span>
                <span className="bg-gray-100 text-xs px-2 py-1 rounded-full">{task.importance}星</span>
                {task.completed ? (
                  <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">已完成</span>
                ) : (
                  <span className="bg-orange-100 text-orange-800 text-xs px-2 py-1 rounded-full">进行中</span>
                )}
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}
