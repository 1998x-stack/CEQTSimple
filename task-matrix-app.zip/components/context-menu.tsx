"use client"

import { useEffect } from "react"

interface ContextMenuProps {
  x: number
  y: number
  onEdit: () => void
  onComplete: () => void
  onDelete: () => void
  onClose: () => void
}

export function ContextMenu({ x, y, onEdit, onComplete, onDelete, onClose }: ContextMenuProps) {
  useEffect(() => {
    const handleClick = () => onClose()
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose()
    }

    document.addEventListener("click", handleClick)
    document.addEventListener("keydown", handleEscape)

    return () => {
      document.removeEventListener("click", handleClick)
      document.removeEventListener("keydown", handleEscape)
    }
  }, [onClose])

  return (
    <div
      className="fixed bg-white rounded-lg shadow-xl border py-2 z-50 min-w-32"
      style={{ left: x, top: y }}
      onClick={(e) => e.stopPropagation()}
    >
      <button className="w-full px-4 py-2 text-left hover:bg-gray-100 flex items-center gap-3 text-sm" onClick={onEdit}>
        <span>✏️</span> 编辑
      </button>
      <button
        className="w-full px-4 py-2 text-left hover:bg-gray-100 flex items-center gap-3 text-sm"
        onClick={onComplete}
      >
        <span>✅</span> 完成
      </button>
      <button
        className="w-full px-4 py-2 text-left hover:bg-gray-100 flex items-center gap-3 text-sm text-red-600"
        onClick={onDelete}
      >
        <span>❌</span> 删除
      </button>
    </div>
  )
}
