interface StatsCardsProps {
  stats: {
    total: number
    completed: number
    pending: number
    completionRate: number
  }
}

export function StatsCards({ stats }: StatsCardsProps) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8 max-w-3xl mx-auto">
      <div className="bg-white rounded-2xl p-6 text-center shadow-lg min-h-32 flex flex-col justify-center">
        <div className="text-sm text-gray-600 mb-2">总任务数</div>
        <div className="text-3xl font-semibold text-black">{stats.total}</div>
      </div>

      <div className="bg-white rounded-2xl p-6 text-center shadow-lg min-h-32 flex flex-col justify-center">
        <div className="text-sm text-gray-600 mb-2">已完成</div>
        <div className="text-3xl font-semibold text-green-500">{stats.completed}</div>
      </div>

      <div className="bg-white rounded-2xl p-6 text-center shadow-lg min-h-32 flex flex-col justify-center">
        <div className="text-sm text-gray-600 mb-2">进行中</div>
        <div className="text-3xl font-semibold text-orange-500">{stats.pending}</div>
      </div>

      <div className="bg-white rounded-2xl p-6 text-center shadow-lg min-h-32 flex flex-col justify-center">
        <div className="text-sm text-gray-600 mb-2">完成率</div>
        <div className="text-3xl font-semibold text-black">{stats.completionRate}%</div>
      </div>
    </div>
  )
}
