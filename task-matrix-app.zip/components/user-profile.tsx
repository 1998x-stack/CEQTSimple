"use client"

import { useMemo } from "react"
import type { Task } from "@/lib/types"
import { StatsCards } from "./stats-cards"
import { TaskTimeline } from "./task-timeline"
import { CategoryChart } from "./category-chart"

interface UserProfileProps {
  user: string
  tasks: Task[]
  onBack: () => void
}

export function UserProfile({ user, tasks, onBack }: UserProfileProps) {
  const stats = useMemo(() => {
    const total = tasks.length
    const completed = tasks.filter((t) => t.completed).length
    const pending = total - completed
    const completionRate = total > 0 ? Math.round((completed / total) * 100) : 0

    return { total, completed, pending, completionRate }
  }, [tasks])

  const createdTasks = useMemo(
    () => tasks.slice().sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
    [tasks],
  )

  const completedTasks = useMemo(
    () =>
      tasks
        .filter((t) => t.completed && t.completedAt)
        .sort((a, b) => {
          const dateA = a.completedAt ? new Date(a.completedAt).getTime() : 0
          const dateB = b.completedAt ? new Date(b.completedAt).getTime() : 0
          return dateB - dateA
        }),
    [tasks],
  )

  return (
    <div className="min-h-screen p-5 pt-20">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8 text-white">
          <h1 className="text-3xl font-bold mb-2">{user} 的任务管理</h1>
          <p className="text-white/80">管理您的任务和时间</p>
        </div>

        {/* Stats Cards */}
        <StatsCards stats={stats} />

        {/* Category Chart */}
        <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-6 mb-6 shadow-lg">
          <CategoryChart tasks={tasks} />
        </div>

        {/* Task Timelines */}
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-lg">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span>📝</span> 新建事件时间流
            </h3>
            <TaskTimeline tasks={createdTasks} type="created" />
          </div>

          <div className="bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-lg">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span>✅</span> 完成事项时间流
            </h3>
            <TaskTimeline tasks={completedTasks} type="completed" />
          </div>
        </div>
      </div>
    </div>
  )
}
