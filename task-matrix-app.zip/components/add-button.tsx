"use client"

interface AddButtonProps {
  position: { x: number; y: number }
  onClick: () => void
}

export function AddButton({ position, onClick }: AddButtonProps) {
  return (
    <button
      className="absolute w-10 h-10 bg-green-500 hover:bg-green-600 border-none rounded-full text-white text-2xl cursor-pointer flex items-center justify-center shadow-lg hover:scale-110 transition-all duration-300 z-30"
      style={{
        left: position.x - 20,
        top: position.y - 20,
      }}
      onClick={onClick}
    >
      +
    </button>
  )
}
