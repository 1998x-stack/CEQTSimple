"use client"

import { create } from "zustand"
import type { Task } from "./types"

interface TaskStore {
  currentUser: string | null
  tasks: Task[]
  isInitialized: boolean
  setCurrentUser: (user: string) => void
  addTask: (task: Omit<Task, "id" | "createdAt" | "completed">) => void
  updateTask: (id: string, updates: Partial<Task>) => void
  deleteTask: (id: string) => void
  completeTask: (id: string) => void
  loadUserData: (username: string) => void
  saveUserData: () => void
}

export const useTaskStore = create<TaskStore>((set, get) => ({
  currentUser: null,
  tasks: [],
  isInitialized: false,

  setCurrentUser: (user) => set({ currentUser: user }),

  addTask: (taskData) => {
    const newTask: Task = {
      ...taskData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      completed: false,
    }
    set((state) => ({ tasks: [...state.tasks, newTask] }))
  },

  updateTask: (id, updates) => {
    set((state) => ({
      tasks: state.tasks.map((task) =>
        task.id === id ? { ...task, ...updates, updatedAt: new Date().toISOString() } : task,
      ),
    }))
  },

  deleteTask: (id) => {
    set((state) => ({
      tasks: state.tasks.filter((task) => task.id !== id),
    }))
  },

  completeTask: (id) => {
    set((state) => ({
      tasks: state.tasks.map((task) =>
        task.id === id ? { ...task, completed: true, completedAt: new Date().toISOString() } : task,
      ),
    }))
  },

  loadUserData: (username) => {
    // Only access localStorage on client side
    if (typeof window === "undefined") return

    const userData = localStorage.getItem(`tasks_${username}`)
    if (userData) {
      try {
        const tasks = JSON.parse(userData)
        set({ tasks, isInitialized: true })
      } catch (error) {
        console.error("Failed to parse user data:", error)
        set({ tasks: [], isInitialized: true })
      }
    } else {
      // Initialize with sample data
      const sampleTasks: Task[] = [
        {
          id: "1",
          title: "完成项目报告",
          description: "准备季度总结报告，包括数据分析和建议",
          category: "work",
          importance: 6,
          urgency: 7,
          createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
          completed: false,
        },
        {
          id: "2",
          title: "健身锻炼",
          description: "每周至少3次有氧运动",
          category: "health",
          importance: 5,
          urgency: 3,
          createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
          completed: false,
        },
        {
          id: "3",
          title: "学习新技能",
          description: "学习React和Vue框架",
          category: "study",
          importance: 4,
          urgency: 1,
          createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
          completed: true,
          completedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        },
      ]
      set({ tasks: sampleTasks, isInitialized: true })
    }
  },

  saveUserData: () => {
    // Only access localStorage on client side
    if (typeof window === "undefined") return

    const { currentUser, tasks } = get()
    if (currentUser) {
      try {
        localStorage.setItem(`tasks_${currentUser}`, JSON.stringify(tasks))
      } catch (error) {
        console.error("Failed to save user data:", error)
      }
    }
  },
}))
