export interface Task {
  id: string
  title: string
  description?: string
  category: string
  importance: number // 1-7
  urgency: number // 0-12
  createdAt: string
  updatedAt?: string
  completed: boolean
  completedAt?: string
}

export interface User {
  username: string
  tasks: Task[]
}
