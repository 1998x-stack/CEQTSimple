import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

const priorityColors = ["#4444ff", "#0088cc", "#00cc88", "#88cc00", "#ffcc00", "#ff8800", "#ff4444"]

export function getTaskColor(importance: number, urgency: number): string {
  const baseColor = priorityColors[importance - 1]
  const opacity = 0.4 + (urgency / 12) * 0.6
  return (
    baseColor +
    Math.floor(opacity * 255)
      .toString(16)
      .padStart(2, "0")
  )
}

export function getCategoryName(category: string): string {
  const categoryMap: Record<string, string> = {
    work: "工作",
    personal: "个人",
    study: "学习",
    health: "健康",
    family: "家庭",
    other: "其他",
  }
  return categoryMap[category] || "其他"
}

export function formatDate(dateString: string): string {
  const date = new Date(dateString)
  const now = new Date()
  const diffTime = Math.abs(now.getTime() - date.getTime())
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))

  if (diffDays === 1) {
    return "今天 " + date.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })
  } else if (diffDays === 2) {
    return "昨天 " + date.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })
  } else if (diffDays <= 7) {
    return diffDays + "天前"
  } else {
    return (
      date.toLocaleDateString("zh-CN") + " " + date.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })
    )
  }
}
