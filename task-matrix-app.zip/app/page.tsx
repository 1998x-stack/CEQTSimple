"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { TaskMatrix } from "@/components/task-matrix"
import { UserProfile } from "@/components/user-profile"
import { LoginModal } from "@/components/login-modal"
import { TaskModal } from "@/components/task-modal"
import { ContextMenu } from "@/components/context-menu"
import { useTaskStore } from "@/lib/store"
import type { Task } from "@/lib/types"

export default function Home() {
  const [currentView, setCurrentView] = useState<"matrix" | "profile">("matrix")
  const [showLoginModal, setShowLoginModal] = useState(false)
  const [showTaskModal, setShowTaskModal] = useState(false)
  const [editingTask, setEditingTask] = useState<Task | null>(null)
  const [contextMenu, setContextMenu] = useState<{
    x: number
    y: number
    taskId: string
  } | null>(null)
  const [isHydrated, setIsHydrated] = useState(false)

  const {
    currentUser,
    tasks,
    setCurrentUser,
    addTask,
    updateTask,
    deleteTask,
    completeTask,
    loadUserData,
    saveUserData,
  } = useTaskStore()

  // Handle hydration
  useEffect(() => {
    setIsHydrated(true)

    // Check for existing user after hydration
    const savedUser = localStorage.getItem("currentUser")
    if (savedUser) {
      setCurrentUser(savedUser)
      loadUserData(savedUser)
    } else {
      setShowLoginModal(true)
    }
  }, [setCurrentUser, loadUserData])

  const handleLogin = (username: string, password: string) => {
    if (!username.trim()) {
      throw new Error("请输入用户名")
    }
    if (password.length < 3) {
      throw new Error("密码长度至少为3位")
    }

    setCurrentUser(username)
    localStorage.setItem("currentUser", username)
    loadUserData(username)
    setShowLoginModal(false)
  }

  const handleAddTask = (x: number, y: number) => {
    setEditingTask(null)
    setShowTaskModal(true)
  }

  const handleEditTask = (task: Task) => {
    setEditingTask(task)
    setShowTaskModal(true)
    setContextMenu(null)
  }

  const handleSaveTask = (taskData: Partial<Task>) => {
    if (editingTask) {
      updateTask(editingTask.id, taskData)
    } else {
      addTask(taskData as Omit<Task, "id" | "createdAt" | "completed">)
    }
    setShowTaskModal(false)
    setEditingTask(null)
    saveUserData()
  }

  const handleDeleteTask = (taskId: string) => {
    if (confirm("确定要删除这个任务吗？")) {
      deleteTask(taskId)
      saveUserData()
    }
    setContextMenu(null)
  }

  const handleCompleteTask = (taskId: string) => {
    completeTask(taskId)
    saveUserData()
    setContextMenu(null)
  }

  const handleContextMenu = (e: React.MouseEvent, taskId: string) => {
    e.preventDefault()
    setContextMenu({
      x: e.pageX,
      y: e.pageY,
      taskId,
    })
  }

  const handleTaskMove = (taskId: string, urgency: number, importance: number) => {
    updateTask(taskId, { urgency, importance })
    saveUserData()
  }

  // Show loading state during hydration
  if (!isHydrated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-500 via-purple-500 to-purple-700 flex items-center justify-center">
        <div className="text-white text-xl">加载中...</div>
      </div>
    )
  }

  if (showLoginModal) {
    return <LoginModal onLogin={handleLogin} />
  }

  if (!currentUser) {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 via-purple-500 to-purple-700">
      {/* Header */}
      <header className="fixed top-0 right-0 z-50 p-5">
        <button
          onClick={() => setCurrentView(currentView === "matrix" ? "profile" : "matrix")}
          className="w-12 h-12 rounded-full bg-gradient-to-r from-red-400 to-teal-400 flex items-center justify-center text-white font-bold shadow-lg hover:scale-110 transition-transform cursor-pointer"
        >
          {currentView === "matrix" ? currentUser.charAt(0).toUpperCase() : "←"}
        </button>
      </header>

      {/* Main Content */}
      {currentView === "matrix" ? (
        <TaskMatrix
          tasks={tasks.filter((t) => !t.completed)}
          onAddTask={handleAddTask}
          onEditTask={handleEditTask}
          onContextMenu={handleContextMenu}
          onTaskMove={handleTaskMove}
        />
      ) : (
        <UserProfile user={currentUser} tasks={tasks} onBack={() => setCurrentView("matrix")} />
      )}

      {/* Modals */}
      {showTaskModal && (
        <TaskModal
          task={editingTask}
          onSave={handleSaveTask}
          onClose={() => {
            setShowTaskModal(false)
            setEditingTask(null)
          }}
        />
      )}

      {contextMenu && (
        <ContextMenu
          x={contextMenu.x}
          y={contextMenu.y}
          onEdit={() => {
            const task = tasks.find((t) => t.id === contextMenu.taskId)
            if (task) handleEditTask(task)
          }}
          onComplete={() => handleCompleteTask(contextMenu.taskId)}
          onDelete={() => handleDeleteTask(contextMenu.taskId)}
          onClose={() => setContextMenu(null)}
        />
      )}
    </div>
  )
}
